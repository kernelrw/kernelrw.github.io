#import <Preferences/PSSpecifier.h>
#import <Preferences/PSTableCell.h>
#import <UIKit/UIKit.h>
#import <NSTask.h>
#import "JCXPackageInfo.h"
#import "NSString+Control.h"
#import "UIColor+HexString.h"

@interface JCXTableCell : PSTableCell {
    PSSpecifier * _Nonnull _specifier;
}
@end
