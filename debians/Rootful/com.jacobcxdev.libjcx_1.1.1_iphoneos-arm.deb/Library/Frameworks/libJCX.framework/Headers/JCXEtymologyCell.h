#import "JCXLinkCell.h"

@interface JCXEtymologyCell : JCXLinkCell {
    NSAttributedString * _Nullable _wordAttributedString;
    NSAttributedString * _Nullable _informationAttributedString;
    NSAttributedString * _Nullable _definitionAttributedString;
}
@end