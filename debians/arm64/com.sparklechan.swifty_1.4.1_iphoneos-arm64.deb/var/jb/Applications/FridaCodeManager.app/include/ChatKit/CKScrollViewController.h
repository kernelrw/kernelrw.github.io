#import "CKViewController.h"

@interface CKScrollViewController : CKViewController

@end
