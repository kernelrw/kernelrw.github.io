#import "OBTrayButton.h"

API_AVAILABLE(ios(13.0))
@interface OBBoldTrayButton : OBTrayButton

+ (instancetype)boldButton;

@end
