#import <UIKit/UIView.h>

@interface SBHomeGrabberView : UIView

- (CGRect)_calculatePillFrame;

@end
