#import <UIKit/UIView.h>

@interface MPUTransportControlsView : UIView

@property (assign) NSInteger minimumNumberOfTransportButtonsForLayout;

@end
