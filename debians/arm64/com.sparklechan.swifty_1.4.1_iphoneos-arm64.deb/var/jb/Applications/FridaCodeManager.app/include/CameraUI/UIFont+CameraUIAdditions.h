#import <UIKit/UIKit.h>

@interface UIFont (CameraUI)

+ (UIFont *)cui_cameraFontOfSize:(CGFloat)size;

@end
