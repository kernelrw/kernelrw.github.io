#import <Foundation/Foundation.h>

API_AVAILABLE(ios(10.0))
@interface _LSQueryResult : NSObject <NSCopying, NSSecureCoding>

@end
