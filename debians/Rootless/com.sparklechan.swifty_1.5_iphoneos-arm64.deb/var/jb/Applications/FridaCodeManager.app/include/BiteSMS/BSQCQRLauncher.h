#import <Foundation/NSObject.h>

@interface BSQCQRLauncher : NSObject

+ (void)showQuickCompose:(BOOL)isLocked;

@end
