#import <Foundation/NSObject.h>

@interface IMItemsController : NSObject

@end
