#import <UIKit/UIView.h>

@interface CKTranscriptTypingIndicatorCell : UIView

- (void)startPulseAnimation;

- (void)stopPulseAnimation;

- (void)startGrowAnimation;

- (void)startShrinkAnimation;

@end
