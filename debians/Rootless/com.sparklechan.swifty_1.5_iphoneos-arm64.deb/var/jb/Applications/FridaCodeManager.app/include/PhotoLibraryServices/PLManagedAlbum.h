#import <Foundation/NSObject.h>
#import <Foundation/NSOrderedSet.h>

@interface PLManagedAlbum : NSObject

@property (nonatomic, retain) NSOrderedSet *assets;

@end
