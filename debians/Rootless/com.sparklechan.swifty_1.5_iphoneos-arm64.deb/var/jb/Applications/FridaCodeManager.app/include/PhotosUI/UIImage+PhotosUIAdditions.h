#import <UIKit/UIKit.h>

@interface UIImage (PhotosUI)

+ (UIImage *)pu_PhotosUIImageNamed:(NSString *)name;

@end
