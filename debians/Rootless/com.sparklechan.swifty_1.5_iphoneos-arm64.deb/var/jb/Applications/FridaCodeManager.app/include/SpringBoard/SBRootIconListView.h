#import "SBIconListView.h"

@interface SBRootIconListView : SBIconListView

@end
