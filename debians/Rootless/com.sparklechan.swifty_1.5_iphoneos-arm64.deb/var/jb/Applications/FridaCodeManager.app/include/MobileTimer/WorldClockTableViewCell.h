// app

#import <UIKit/UITableViewCell.h>

@class WorldClockCity;

@interface WorldClockTableViewCell : UITableViewCell

@property (nonatomic, retain) WorldClockCity *city;

@end
