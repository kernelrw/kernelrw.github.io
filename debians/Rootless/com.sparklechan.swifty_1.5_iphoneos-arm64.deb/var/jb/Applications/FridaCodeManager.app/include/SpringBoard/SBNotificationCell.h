#import <UIKit/UIView.h>
#import <UIKit/UITableViewCell.h>

@interface SBNotificationCell : UITableViewCell

@property (nonatomic, retain) UIView *realContentView;

@end
