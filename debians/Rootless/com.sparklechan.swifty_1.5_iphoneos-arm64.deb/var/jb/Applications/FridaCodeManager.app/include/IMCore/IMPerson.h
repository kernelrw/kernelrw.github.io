#import <Foundation/NSObject.h>
#import <Foundation/NSString.h>

@interface IMPerson : NSObject

@property (nonatomic, readonly) NSString *name;

@end
