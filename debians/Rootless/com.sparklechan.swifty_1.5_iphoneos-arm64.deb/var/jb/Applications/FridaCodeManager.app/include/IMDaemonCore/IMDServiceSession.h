#import <Foundation/NSObject.h>

@interface IMDServiceSession : NSObject

@end
