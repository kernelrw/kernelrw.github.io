#import <Foundation/NSObject.h>

@interface AVItem : NSObject

@end
