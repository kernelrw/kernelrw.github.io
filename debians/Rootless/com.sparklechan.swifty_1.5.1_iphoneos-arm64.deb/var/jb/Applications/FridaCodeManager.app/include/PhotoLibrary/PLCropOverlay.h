#import <UIKit/UIKit.h>

@interface PLCropOverlay : UIView

- (void)setShowProgress:(BOOL)showProgress title:(NSString *)title;

@end
