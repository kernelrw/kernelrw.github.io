#import "CKViewController.h"

@class CKConversation;

@interface CKTranscriptManagementController : CKViewController

- (instancetype)initWithConversation:(CKConversation *)conversation;

@end
