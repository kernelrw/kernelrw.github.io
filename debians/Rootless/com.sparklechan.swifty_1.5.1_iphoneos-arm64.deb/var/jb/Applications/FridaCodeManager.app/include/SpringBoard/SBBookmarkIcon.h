#import <Foundation/NSObject.h>

@interface SBBookmarkIcon : NSObject

@end
