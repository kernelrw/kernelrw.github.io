#import <UIKit/UIView.h>

@interface MPUMediaRemoteControlsView : UIView

@end
