#import <AVFoundation/AVFoundation.h>

@interface AVCaptureFigVideoDevice : AVCaptureDevice
@end
