#import "SBIconListView.h"

@interface SBDockIconListView : SBIconListView

@end
