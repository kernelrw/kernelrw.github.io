#import <BulletinBoard/BBBulletin.h>
#import <MobileIcons/MobileIcons.h>
#import <UIKit/UIImage.h>

@interface BBBulletin (SpringBoardAdditions)

- (UIImage *)sectionIconImageWithFormat:(MIIconVariant)format;

@end