#import <Foundation/NSObject.h>
#import <Foundation/NSArray.h>

@interface SBDisplayLayout : NSObject

@property (nonatomic, retain, readonly) NSArray *displayItems;

@end
