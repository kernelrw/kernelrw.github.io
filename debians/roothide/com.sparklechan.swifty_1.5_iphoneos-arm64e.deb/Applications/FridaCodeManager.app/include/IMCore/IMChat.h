#import "IMItemsController.h"

@class IMHandle;

@interface IMChat : IMItemsController

@property (nonatomic, retain) IMHandle *recipient;

@end
