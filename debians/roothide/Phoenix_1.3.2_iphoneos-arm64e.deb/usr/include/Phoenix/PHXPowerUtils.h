#import <Foundation/Foundation.h>
#import <rootless.h>
#import <spawn.h>

@interface PHXPowerUtils : NSObject
+ (void)respring;
+ (void)reboot;
+ (void)safemode;
+ (void)shutdown;
+ (void)uicache;
@end