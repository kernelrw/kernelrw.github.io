#import <Preferences/PSTableCell.h>
#import <Preferences/PSSpecifier.h>
#import <UIKit/UIImage+Private.h>
#import <UIKit/UIKit.h>
#import <rootless.h>

@interface PHXGithubCell : PSTableCell
@property (nonatomic, retain) UIView *baseView;
@property (nonatomic, retain) UILabel *nameLabel;
@property (nonatomic, retain) UILabel *descLabel;
@end