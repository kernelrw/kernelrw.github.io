#import <UIKit/UIKit.h>
#import "PHXDevice.h"

@interface PHXBannerView : UIView
@property (nonatomic, retain) UIImageView *imageView;
- (id)initWithFrame:(CGRect)frame image:(UIImage *)image;
@end