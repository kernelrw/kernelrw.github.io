#import <Preferences/PSSpecifier.h>
#import <UIKit/UIKit.h>
#import <rootless.h>
#import "PHXImage.h"

@interface PHXIconLinkCell : PSTableCell
@property (nonatomic, retain) UIView *baseView;
@property (nonatomic, retain) UIImageView *iconView;
@property (nonatomic, retain) UILabel *nameLabel;
@end