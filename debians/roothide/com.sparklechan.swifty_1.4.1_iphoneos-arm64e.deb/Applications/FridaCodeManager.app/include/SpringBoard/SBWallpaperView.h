#import <UIKit/UIKit.h>

@interface SBWallpaperView : UIImageView

@end
