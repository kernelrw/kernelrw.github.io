#import <Foundation/NSObject.h>

@interface BBSectionSubtypeParameters : NSObject

@property (nonatomic) BOOL allowsAddingToLockScreenWhenUnlocked;
@property (nonatomic) BOOL allowsAutomaticRemovalFromLockScreen;
@property (nonatomic) BOOL prioritizeAtTopOfLockScreen;

@end
