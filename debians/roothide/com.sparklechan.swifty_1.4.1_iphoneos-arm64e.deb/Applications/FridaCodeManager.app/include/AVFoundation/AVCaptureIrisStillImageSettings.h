#import <Foundation/Foundation.h>

API_DEPRECATED("Removed in iOS 10", ios(9.0, 10.0))
@interface AVCaptureIrisStillImageSettings : NSObject

@property (assign, nonatomic) NSInteger irisMovieMode;

@end
