#import <Foundation/NSObject.h>
#import <Foundation/NSString.h>

@interface AppSchemeCoordinator : NSObject

+ (void)openRedditThreadUrl:(NSString *)url;

@end
