#import "SBBBBulletinInfo.h"

@interface SBNotificationsBulletinInfo : SBBBBulletinInfo

@end
