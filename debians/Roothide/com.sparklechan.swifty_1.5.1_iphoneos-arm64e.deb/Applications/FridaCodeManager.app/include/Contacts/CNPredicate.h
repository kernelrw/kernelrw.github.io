#import <Foundation/NSPredicate.h>

@interface CNPredicate : NSPredicate

@end
