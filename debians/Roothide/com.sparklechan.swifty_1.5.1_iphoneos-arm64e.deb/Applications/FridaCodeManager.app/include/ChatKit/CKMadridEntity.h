#import "CKIMEntity.h"

// 5.x

@interface CKMadridEntity : CKIMEntity

@end
