// app

#import <UIKit/UICollectionViewCell.h>

@class WorldClockView;

@interface WorldClockCollectionCell : UICollectionViewCell

@property (retain, nonatomic) WorldClockView *clockView;

@end
